from robocorp.tasks import task
from RPA.HTTP import HTTP

@task
def download_file():
    objHTTP=HTTP()
    objHTTP.download(url="https://robotsparebinindustries.com/SalesData.xlsx",overwrite=True,target_file="C:\\Deekshit\\test_SalesData123.xlsx")
