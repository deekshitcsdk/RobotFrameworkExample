from RPA.Archive import Archive
from RPA.Browser import _Selenium
objArchive=Archive()
objArchive.archive_folder_with_zip("C:\\TURBOC3\\","TurboC3.zip")






