from robocorp import browser
from robocorp.tasks import task
from RPA.HTTP import HTTP
from RPA.Excel.Files import Files
from RPA.PDF import PDF
page=browser.page()

@task
def openbrowser():
    browser.goto("https://robotsparebinindustries.com/")
    browser.configure(slowmo=1000)
    portal_login()

def portal_login():
    page.wait_for_load_state()
    page.fill("#username","maria")
    page.fill("#password","thoushallnotpass")
    page.click("text=Log In")
    #browser.screenshot()
    page.wait_for_load_state()
    #browser.screenshot()
    download_file()
    readExcel()
    page.click("text=Show performance")
    browser.screenshot()
    exportPDF()
    page.click("text=Log out")

def fill_form(dtRow):
    page.fill("#firstname", str(dtRow["First Name"]))
    page.fill("#lastname", str(dtRow["Last Name"]))
    page.fill("#salesresult", str(dtRow["Sales"]))
    page.select_option("#salestarget", str(dtRow["Sales Target"]))
    page.click("text=Submit")
    page.wait_for_load_state()

def download_file():
    objHTTP=HTTP()
    objHTTP.download(url="https://robotsparebinindustries.com/SalesData.xlsx",overwrite=True,target_file="./output/")

def readExcel():
    objExcelFile=Files()
    objExcelFile.open_workbook("./output/SalesData.xlsx")
    dtSalesData=objExcelFile.read_worksheet_as_table("data",header=True)
    objExcelFile.close_workbook()
    for tr in dtSalesData:
        fill_form(tr)
    
def exportPDF():
    salesresultsHTML=page.locator("#sales-results").inner_html()
    objPDF=PDF()
    objPDF.html_to_pdf(salesresultsHTML,"./output/salesresults.pdf")