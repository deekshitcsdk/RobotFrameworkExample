from robocorp.tasks import task
from robocorp.browser import browser
@task
def minimal_task():
    browser.goto("https://www.google.co.in")
