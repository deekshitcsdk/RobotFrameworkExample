from robocorp import browser
from robocorp.tasks import task
from RPA.HTTP import HTTP
from RPA.PDF import PDF
from RPA.Tables import Tables
from RPA.Archive import Archive
from datetime import datetime
import os

@task
def Chapter2():
    if os.path.exists("./output/finalorders") == False:
        os.makedirs("./output/finalorders")
    cleanfiles()
    OrderRobots()
    zipArchive()
    cleanfiles()
    
def download_file():
    objHTTP=HTTP()
    objHTTP.download(url="https://robotsparebinindustries.com/orders.csv",overwrite=True,target_file="./output/orders.csv")

def OrderRobots():
    download_file()
    openportal()
    objOrderTable=Tables()
    objOrderTable=Tables.read_table_from_csv(objOrderTable,path="./output/orders.csv",header=True)
    for row in objOrderTable:
        fill_orderform(row)

def openportal():
    browser.goto("https://robotsparebinindustries.com/#/robot-order")
    browser.configure(slowmo=1000)
    
def closemodal():
    page=browser.page()
    page.click("text=OK")

def order():
    page=browser.page()
    page.click("#order")


def ordernext():
    page=browser.page()
    page.click("#order-another")

def fill_orderform(trow):
    page=browser.page()
    closemodal()
    page.select_option("#head", str(trow["Head"]))
    page.check("#id-body-"+str(trow["Body"]))
    page.fill("input[type='number']",str(trow["Legs"]))
    page.fill("#address",str(trow["Address"]))
    strError=""
    order()
    #page.screenshot()
    strOrderNumber=str(trow["Order number"])
    orderdetails=""#page.locator("#receipt").inner_html()
    while orderdetails =="":
        try:
            orderdetails=page.locator("#receipt").inner_html()
            if orderdetails!="":
                break
        except:
            order()
            #orderdetails=page.locator("#receipt").inner_html()
    
    robotimage=page.locator("#robot-preview").inner_html()
    page.locator("#robot-preview-image").screenshot(path="./output/robotimage_"+strOrderNumber+".png")
    objPDF=None
    objPDF=PDF()
    
    if(orderdetails!=""):
        objPDF.html_to_pdf(orderdetails,"./output/orderresults_"+strOrderNumber+".pdf")
        #objPDF.html_to_pdf(robotimage,"./output/robotimage_"+strOrderNumber+".pdf")
    
        pdflist=None
        pdflist=["./output/orderresults_"+strOrderNumber+".pdf", "./output/robotimage_"+strOrderNumber+".png"]
        objPDF.add_files_to_pdf(files=pdflist,target_document="./output/finalorders/finalorder_"+strOrderNumber+".pdf")
        #objPDF.append(pdflist)
    ordernext()
    

def zipArchive():
    zip=Archive()
    zip.archive_folder_with_zip("./output/finalorders/","./output/archive"+datetime.now().strftime("%Y%m%d")+".zip")
    
def cleanfiles():
    for item in os.listdir("./output/"):
        if str(item).endswith(".pdf") or str(item).endswith(".png"):
            os.remove(os.path.join("./output/",item))
    
    for item in os.listdir("./output/finalorders/"):
        if str(item).endswith(".pdf"):
            os.remove(os.path.join("./output/finalorders",item))
    